import{a as e,n as t}from"./Button-COsPX9A4.js";import{S as n,Y as r}from"./index-C2dflxg-.js";var i=t(`quote`,[[`path`,{d:`M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z`,key:`rib7q0`}],[`path`,{d:`M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z`,key:`1ymkrd`}]]),a=e();function o({badge:e,title:t,description:i,centered:o}){return(0,a.jsxs)(`div`,{className:o?`mx-auto flex max-w-3xl flex-col items-center text-center`:`max-w-3xl`,children:[e&&(0,a.jsx)(`span`,{className:`
            mb-4
            inline-flex
            items-center
            rounded-full
            bg-slate-100
            px-4
            py-2
            text-xs
            font-medium
            text-[#0c2578]
          `,children:e}),(0,a.jsx)(n,{size:`xl`,children:t}),i&&(0,a.jsx)(r,{color:`muted`,className:`mt-4`,children:i})]})}export{i as n,o as t};