import{a as e,i as t,n,r,t as i}from"./Button-COsPX9A4.js";import{t as a}from"./clock-3-D9DNny55.js";import{t as o}from"./phone-Csz4IsfM.js";import{H as s,S as c,T as l,X as u,Y as d,a as f,b as p,d as m,f as h,g,h as _,i as v,m as y,n as b,t as x,v as S,x as C,z as w}from"./index-C2dflxg-.js";import{t as T}from"./contact.config-CxZtYofr.js";var E=n(`mail`,[[`path`,{d:`m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7`,key:`132q7q`}],[`rect`,{x:`2`,y:`4`,width:`20`,height:`16`,rx:`2`,key:`izxlao`}]]),D=n(`message-square`,[[`path`,{d:`M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z`,key:`18887p`}]]),O=n(`send`,[[`path`,{d:`M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z`,key:`1ffxy3`}],[`path`,{d:`m21.854 2.147-10.94 10.939`,key:`12cjpa`}]]),k=n(`user`,[[`path`,{d:`M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2`,key:`975kel`}],[`circle`,{cx:`12`,cy:`7`,r:`4`,key:`17ys0d`}]]),A=e();function j({children:e}){let{formState:{isSubmitting:t,isValid:n}}=S();return(0,A.jsx)(i,{type:`submit`,loading:t,disabled:!n||t,variant:`primary`,size:`lg`,className:`ml-auto inline-flex items-center justify-center gap-2 font-medium transition-all duration-200 focus:outline-none disabled:pointer-events-none disabled:opacity-50 bg-[var(--color-primary)] text-white hover:opacity-90 h-12 px-6 text-base rounded-xl min-w-[180px]
    `,iconRight:!t&&(0,A.jsx)(O,{size:18}),children:t?`Sending...`:e})}var M=m.object({name:m.string().min(2,`Name is too short`),email:m.string().email(`Invalid email`),phone:m.string().optional(),subject:m.string().min(3,`Subject is too short`),message:m.string().min(10,`Message is too short`)});function N(){return h(M,{defaultValues:{name:``,email:``,phone:``,subject:``,message:``},mode:`onTouched`,reValidateMode:`onChange`})}var P={async submitContactForm(e){return console.log(`Contact form submitted:`,e),{success:!0,message:`Your message has been sent successfully.`}}};function F(){let e=N(),{success:t,error:n}=x(),{register:r,formState:{errors:i,dirtyFields:a}}=e;return(0,A.jsx)(g,{methods:e,onSubmit:async r=>{try{t({title:`Message Sent`,description:(await P.submitContactForm(r)).message}),e.reset()}catch{n({title:`Submission Failed`,description:`Unable to send your message right now.`})}},children:(0,A.jsxs)(y,{title:`Contact Us`,description:`Send us a message and our team will get back to you.`,children:[(0,A.jsx)(b,{label:`Full Name`,error:i.name?.message,children:(0,A.jsx)(f,{placeholder:`John Smith`,icon:(0,A.jsx)(k,{className:`h-4 w-4`}),...r(`name`),error:!!i.name,success:!!a.name&&!i.name})}),(0,A.jsx)(b,{label:`Email Address`,error:i.email?.message,helperText:`We'll never share your email.`,children:(0,A.jsx)(f,{type:`email`,placeholder:`name@example.com`,icon:(0,A.jsx)(E,{className:`h-4 w-4`}),...r(`email`),error:!!i.email,success:!!a.email&&!i.email})}),(0,A.jsx)(b,{label:`Phone Number`,error:i.phone?.message,children:(0,A.jsx)(f,{placeholder:`+27 00 000 0000`,icon:(0,A.jsx)(o,{className:`h-4 w-4`}),...r(`phone`),error:!!i.phone,success:!!a.phone&&!i.phone})}),(0,A.jsx)(b,{label:`Subject`,error:i.subject?.message,children:(0,A.jsx)(f,{placeholder:`How can we help?`,icon:(0,A.jsx)(D,{className:`h-4 w-4`}),...r(`subject`),error:!!i.subject,success:!!a.subject&&!i.subject})}),(0,A.jsx)(b,{label:`Message`,error:i.message?.message,children:(0,A.jsx)(v,{rows:5,placeholder:`
Tell us how we can help...
`,...r(`message`),error:!!i.message,success:!!a.message&&!i.message})}),(0,A.jsx)(j,{children:`Send Message`})]})})}function I(){return(0,A.jsxs)(u,{gap:`lg`,children:[(0,A.jsxs)(`div`,{children:[(0,A.jsx)(c,{size:`lg`,children:`Contact Details`}),(0,A.jsx)(d,{variant:`sm`,className:`mt-2 text-slate-500`,children:`Reach our team through any of the channels below.`})]}),(0,A.jsx)(u,{gap:`lg`,children:T.map(e=>(0,A.jsxs)(`div`,{className:`
              flex
              gap-4
              rounded-2xl
              transition
              hover:bg-slate-50
              p-2
            `,children:[(0,A.jsx)(l,{children:e.icon}),(0,A.jsxs)(`div`,{children:[(0,A.jsx)(d,{variant:`sm`,className:`font-semibold text-slate-800`,children:e.title}),(0,A.jsx)(`div`,{className:`mt-1 space-y-1`,children:e.lines.map(e=>(0,A.jsx)(d,{variant:`sm`,className:`text-slate-500`,children:e},e))}),e.highlight&&(0,A.jsx)(d,{variant:`sm`,className:`
                    mt-2
                    font-semibold
                    text-green-600
                  `,children:e.highlight})]})]},e.title))})]})}function L(){return(0,A.jsxs)(A.Fragment,{children:[(0,A.jsx)(C,{..._.contact}),(0,A.jsxs)(p,{className:`
          relative
          overflow-hidden
          bg-gradient-to-b
          from-slate-50
          via-white
          to-slate-100
          py-20
        `,children:[(0,A.jsxs)(`div`,{className:`absolute inset-0 pointer-events-none`,children:[(0,A.jsx)(`div`,{className:`
              absolute
              -left-40
              top-0
              h-[30rem]
              w-[30rem]
              rounded-full
              bg-green-500/5
              blur-3xl
            `}),(0,A.jsx)(`div`,{className:`
              absolute
              -right-40
              bottom-0
              h-[30rem]
              w-[30rem]
              rounded-full
              bg-blue-500/5
              blur-3xl
            `})]}),(0,A.jsx)(t,{children:(0,A.jsxs)(`div`,{className:`relative mx-auto max-w-6xl`,children:[(0,A.jsxs)(`div`,{className:`mx-auto mb-14 max-w-3xl text-center`,children:[(0,A.jsx)(`span`,{className:`
                  inline-flex
                  rounded-full
                  border
                  border-green-200
                  bg-green-50
                  px-4
                  py-2
                  text-sm
                  font-semibold
                  text-green-700
                `,children:`Askari Insurance Support`}),(0,A.jsx)(`h1`,{className:`
                  mt-6
                  text-4xl
                  font-bold
                  tracking-tight
                  text-slate-900
                  md:text-5xl
                `,children:`We’re here when you need us`}),(0,A.jsx)(`p`,{className:`
                  mt-5
                  text-lg
                  leading-relaxed
                  text-slate-600
                `,children:`Speak with our insurance specialists for claims, fleet protection, cargo cover, Yellow Card assistance, and tailored insurance solutions.`})]}),(0,A.jsxs)(`div`,{className:`
                grid
                gap-8
                lg:grid-cols-[400px_1fr]
              `,children:[(0,A.jsxs)(r,{className:`
                  relative
                  overflow-hidden
                  rounded-3xl
                  border
                  border-slate-200
                  bg-white
                  p-8
                  shadow-xl
                  shadow-slate-200/40
                `,children:[(0,A.jsx)(`div`,{className:`
                    absolute
                    inset-x-0
                    top-0
                    h-1
                    bg-gradient-to-r
                    from-green-500
                    via-blue-500
                    to-cyan-500
                  `}),(0,A.jsx)(I,{}),(0,A.jsxs)(`div`,{className:`
                    mt-10
                    space-y-4
                    rounded-2xl
                    bg-slate-50
                    p-5
                  `,children:[(0,A.jsxs)(`div`,{className:`flex gap-3`,children:[(0,A.jsx)(w,{className:`text-green-600`}),(0,A.jsxs)(`div`,{children:[(0,A.jsx)(`p`,{className:`font-semibold text-slate-800`,children:`Secure communication`}),(0,A.jsx)(`p`,{className:`text-sm text-slate-500`,children:`Your information is handled securely.`})]})]}),(0,A.jsxs)(`div`,{className:`flex gap-3`,children:[(0,A.jsx)(a,{className:`text-blue-600`}),(0,A.jsxs)(`div`,{children:[(0,A.jsx)(`p`,{className:`font-semibold text-slate-800`,children:`Fast response`}),(0,A.jsx)(`p`,{className:`text-sm text-slate-500`,children:`We normally respond within one business day.`})]})]})]})]}),(0,A.jsxs)(r,{className:`
                  relative
                  overflow-hidden
                  rounded-3xl
                  border
                  border-slate-200
                  bg-white
                  p-8
                  shadow-xl
                  shadow-slate-200/40
                  md:p-10
                `,children:[(0,A.jsx)(`div`,{className:`
                    absolute
                    inset-x-0
                    top-0
                    h-1
                    bg-gradient-to-r
                    from-green-500
                    via-blue-500
                    to-cyan-500
                  `}),(0,A.jsx)(`div`,{className:`mb-8`,children:(0,A.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,A.jsx)(`div`,{className:`
                        flex
                        h-12
                        w-12
                        items-center
                        justify-center
                        rounded-2xl
                        bg-green-50
                      `,children:(0,A.jsx)(s,{className:`text-green-600`})}),(0,A.jsxs)(`div`,{children:[(0,A.jsx)(`h2`,{className:`text-xl font-semibold text-slate-900`,children:`Send us a message`}),(0,A.jsx)(`p`,{className:`text-sm text-slate-500`,children:`Our team will get back to you shortly.`})]})]})}),(0,A.jsx)(F,{})]})]})]})})]})]})}export{L as default};