import{a as e,i as t,r as n,t as r}from"./Button-COsPX9A4.js";import{t as i}from"./clock-3-D9DNny55.js";import{t as a}from"./phone-Csz4IsfM.js";import{G as o,W as s,q as c,x as l,z as u}from"./index-C2dflxg-.js";var d=e();function f(){return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(l,{title:`Claim Submitted Successfully`,subtitle:`Your claim has been received and is now being processed.`,breadcrumbs:[{label:`Home`,to:`/`},{label:`Claims`,to:`/claims`},{label:`Success`}]}),(0,d.jsx)(`section`,{className:`
          bg-gradient-to-b
          from-slate-50
          via-white
          to-slate-100
          py-16
        `,children:(0,d.jsx)(t,{children:(0,d.jsxs)(`div`,{className:`mx-auto max-w-5xl space-y-10`,children:[(0,d.jsxs)(n,{className:`
                relative
                overflow-hidden
                rounded-3xl
                border
                border-slate-200
                bg-white
                p-10
                text-center
                shadow-xl
                shadow-slate-200/40
              `,children:[(0,d.jsx)(`div`,{className:`
                  absolute
                  right-0
                  top-0
                  h-72
                  w-72
                  rounded-full
                  bg-green-500/10
                  blur-3xl
                `}),(0,d.jsxs)(`div`,{className:`relative`,children:[(0,d.jsx)(`div`,{className:`flex justify-center`,children:(0,d.jsx)(`div`,{className:`
                      rounded-full
                      bg-green-50
                      p-4
                      ring-8
                      ring-green-50/60
                    `,children:(0,d.jsx)(o,{className:`text-green-600`,size:42})})}),(0,d.jsx)(`h1`,{className:`
                    mt-8
                    text-3xl
                    font-bold
                    tracking-tight
                    text-slate-900
                    md:text-4xl
                  `,children:`Claim Received`}),(0,d.jsx)(`p`,{className:`
                    mx-auto
                    mt-4
                    max-w-xl
                    text-slate-500
                    leading-relaxed
                  `,children:`Thank you for submitting your claim. Our team has received your information and will begin reviewing your documents.`}),(0,d.jsxs)(`div`,{className:`
                    mx-auto
                    mt-8
                    max-w-md
                    rounded-2xl
                    border
                    border-green-200
                    bg-green-50
                    px-6
                    py-5
                  `,children:[(0,d.jsx)(`p`,{className:`text-xs font-medium uppercase tracking-wide text-green-700`,children:`Claim Reference Number`}),(0,d.jsx)(`p`,{className:`
                      mt-2
                      text-xl
                      font-bold
                      tracking-wide
                      text-green-800
                    `,children:`CLM-2026-001245`})]}),(0,d.jsxs)(`p`,{className:`
                    mt-6
                    text-sm
                    text-slate-500
                  `,children:[`Estimated review time:`,(0,d.jsx)(`span`,{className:`font-semibold text-slate-700`,children:` 3–5 business days`})]})]})]}),(0,d.jsxs)(n,{className:`
                rounded-3xl
                border
                border-slate-200
                bg-white
                p-8
                shadow-lg
                shadow-slate-200/30
              `,children:[(0,d.jsxs)(`div`,{className:`mb-8 flex items-center gap-3`,children:[(0,d.jsx)(u,{className:`text-green-600`}),(0,d.jsx)(`h2`,{className:`text-xl font-semibold text-slate-900`,children:`What happens next?`})]}),(0,d.jsx)(`div`,{className:`space-y-8`,children:[{icon:s,title:`Claim Logged`,text:`Your claim details and attachments have been securely recorded.`},{icon:i,title:`Assessment in Progress`,text:`A claims specialist will review your information and validate the details.`},{icon:a,title:`Updates & Communication`,text:`We will contact you if additional information is required.`}].map((e,t)=>{let n=e.icon;return(0,d.jsxs)(`div`,{className:`flex gap-5`,children:[(0,d.jsxs)(`div`,{className:`relative`,children:[(0,d.jsx)(`div`,{className:`
                            flex
                            h-12
                            w-12
                            items-center
                            justify-center
                            rounded-2xl
                            bg-slate-100
                          `,children:(0,d.jsx)(n,{className:`text-[#0c2578]`,size:22})}),t!==2&&(0,d.jsx)(`div`,{className:`
                              absolute
                              left-1/2
                              top-12
                              h-10
                              w-px
                              -translate-x-1/2
                              bg-slate-200
                            `})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`h3`,{className:`font-semibold text-slate-900`,children:e.title}),(0,d.jsx)(`p`,{className:`mt-1 text-sm leading-relaxed text-slate-500`,children:e.text})]})]},e.title)})})]}),(0,d.jsx)(n,{className:`
                rounded-3xl
                border
                border-slate-200
                bg-white
                p-8
                text-white
              `,children:(0,d.jsxs)(`div`,{className:`
                  flex
                  flex-col
                  gap-6
                  
                  md:flex-row
                  md:items-center
                  md:justify-between
                `,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`h3`,{className:`text-xl text-slate-700 font-semibold`,children:`Need help with your claim?`}),(0,d.jsx)(`p`,{className:`mt-2 text-sm text-slate-300`,children:`Our support team is available if you need assistance.`})]}),(0,d.jsxs)(r,{size:`lg`,to:`/`,className:`btn
                  `,children:[`Return Home`,(0,d.jsx)(c,{className:`ml-2 h-4 w-4`})]})]})}),(0,d.jsx)(`p`,{className:`
                text-center
                text-xs
                text-slate-400
              `,children:`If you need to update your claim, please contact support within 24 hours of submission.`})]})})})]})}export{f as default};