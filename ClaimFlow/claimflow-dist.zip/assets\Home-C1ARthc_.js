import{a as e,c as t,i as n,o as r,r as i,s as a,t as o}from"./Button-COsPX9A4.js";import{t as s}from"./clock-3-D9DNny55.js";import{A as c,D as l,E as u,G as d,L as f,M as p,N as m,O as h,P as g,X as _,Y as v,k as y,q as b,y as x,z as S}from"./index-C2dflxg-.js";import"./about.config.data-DKWNL8L1.js";import{t as C}from"./Badge-CTGCbrJZ.js";var w=[{value:`10K+`,label:`Active Policies`,delay:`delay-5`},{value:`15`,label:`Countries`,delay:`delay-6`},{value:`24/7`,label:`Support`,delay:`delay-7`}],T={badge:`Trusted by 10,000+ transporters across Africa`,title:{line1:`Protecting `,line2:`African Trade, `,highlight:`One Journey`,line3:`at a `,line4:`Time`},description:`Comprehensive insurance solutions for transporters, fleet operators, and cross-border businesses throughout Africa.`,claimsPaid:`R500M+`,satisfactionRate:`98%`},E=[{id:`licensed`,icon:`shield`,label:`Licensed & Regulated`,subtext:`By insurance authorities`},{id:`claims`,icon:`clock`,label:`24-Hour Claims`,subtext:`Fast processing`},{id:`pan-african`,icon:`globe`,label:`Pan-African`,subtext:`15 countries covered`},{id:`support`,icon:`users`,label:`Expert Support`,subtext:`Dedicated advisors`}],D=e();function O({children:e,loaded:t,animation:n=`animate-up`,delay:i=``,className:a}){return(0,D.jsx)(`div`,{className:r(`pre-animate`,t&&`${n} ${i}`,a),children:e})}function k(){return(0,D.jsxs)(`div`,{className:`space-y-6`,children:[(0,D.jsxs)(`div`,{className:`
        flex
        flex-col
        items-start
        gap-4

        sm:flex-row
        sm:items-center
        `,children:[(0,D.jsxs)(o,{to:`/claims/get-quote`,size:`lg`,className:`
          inline-flex items-center justify-center gap-2 font-medium transition-all duration-200 focus:outline-none disabled:pointer-events-none disabled:opacity-50 bg-[var(--color-primary)] text-white hover:opacity-90 h-12 text-base rounded-full px-7 shadow-lg shadow-blue-900/20
          `,iconRight:(0,D.jsx)(b,{className:`
              transition-transform
              duration-300
              
              `}),children:[`Get Your Instant Quote`,(0,D.jsx)(`span`,{className:`
            pointer-events-none

            absolute

            inset-y-0

            -left-20

            w-16

            rotate-12

            bg-white/30

            blur-md

            transition-all

            duration-1000

            group-hover:left-[120%]
            `})]}),(0,D.jsxs)(o,{to:`/products`,variant:`ghost`,size:`lg`,className:`
          group

          px-2

          text-base

          font-medium

          text-white/80

          hover:bg-transparent

          hover:text-white
          `,children:[`Explore Products`,(0,D.jsx)(b,{size:18,className:`
            ml-2

            transition-transform

            duration-300

            group-hover:translate-x-1
            `})]})]}),(0,D.jsxs)(`div`,{className:`
        flex

        flex-wrap

        items-center

        gap-x-6

        gap-y-1

        text-sm

        text-slate-400
        `,children:[(0,D.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,D.jsx)(S,{size:16,className:`text-emerald-400`}),(0,D.jsx)(`span`,{children:`No paperwork required`})]}),(0,D.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,D.jsx)(s,{size:16,className:`text-sky-400`}),(0,D.jsx)(`span`,{children:`Quotes in under 60 seconds`})]})]})]})}function A({children:e,className:t}){return(0,D.jsx)(`span`,{className:r(`gradient-text`,t),children:e})}function j(){return(0,D.jsxs)(`h1`,{className:`
      mt-8

      max-w-[14ch]

      font-black

      tracking-[-0.06em]

      text-white

      leading-[0.92]

      text-[2.6rem]

      sm:text-[3rem]

      lg:text-[3.8rem]

      xl:text-[3.8rem]
      `,children:[(0,D.jsx)(`span`,{children:T.title.line1}),(0,D.jsx)(`span`,{className:`mt-2 font-semibold text-white/90`,children:T.title.line2}),(0,D.jsxs)(`span`,{className:`relative mt-2 inline-block`,children:[(0,D.jsx)(A,{children:T.title.highlight}),(0,D.jsx)(`span`,{className:`
          absolute

          inset-x-4

          bottom-2

          -z-10

          h-6

          rounded-full

          bg-orange-500/30

          blur-2xl
          `})]}),(0,D.jsx)(`span`,{className:` font-semibold text-white/95`,children:T.title.line3}),(0,D.jsx)(`span`,{className:`mt-2  text-white/70`,children:T.title.line4})]})}function M(){return(0,D.jsx)(`div`,{className:`
        mt-12
        grid
        grid-cols-2
        gap-4
        sm:flex
        sm:flex-wrap
      `,children:w.map(e=>(0,D.jsxs)(`div`,{className:`
            group

            rounded-2xl

            border
            border-white/10

            bg-white/5

            px-5
            py-4

            backdrop-blur-xl

            transition-all
            duration-300

            hover:-translate-y-1
            hover:border-white/20
            hover:bg-white/10

            `,children:[(0,D.jsx)(`p`,{className:`
              text-2xl
              font-bold
              tracking-tight
              text-white
            `,children:e.value}),(0,D.jsx)(`p`,{className:`
              mt-1
              text-xs
              text-blue-100/60
            `,children:e.label})]},e.label))})}function N(){return(0,D.jsxs)(C,{className:`trusted-badge mb-8`,children:[(0,D.jsx)(`div`,{className:`flex h-5 w-5 items-center justify-center rounded-full`,children:(0,D.jsx)(p,{size:12,className:`text-[#E65731]`})}),T.badge]})}function P({loaded:e}){return(0,D.jsxs)(`div`,{className:`
      relative

      max-w-[720px]

      lg:pr-10
      `,children:[(0,D.jsx)(O,{loaded:e,animation:`animate-up`,children:(0,D.jsx)(N,{})}),(0,D.jsx)(O,{loaded:e,animation:`animate-up`,children:(0,D.jsx)(j,{})}),(0,D.jsx)(O,{loaded:e,animation:`animate-up`,children:(0,D.jsx)(`p`,{className:`
          mt-10

          max-w-2xl

          text-[20px]

          leading-[1.9]

          tracking-[-0.01em]

          text-slate-300
          `,children:T.description})}),(0,D.jsx)(O,{loaded:e,animation:`animate-up`,children:(0,D.jsx)(`div`,{className:`mt-12`,children:(0,D.jsx)(k,{})})}),(0,D.jsx)(O,{loaded:e,animation:`animate-up`,children:(0,D.jsx)(`div`,{className:`mt-14`,children:(0,D.jsx)(M,{})})})]})}var F=`/assets/Container-BEV3I1x_.svg`;function I(){return(0,D.jsxs)(`div`,{className:`
        absolute
        left-0 top-16
        sm:left-0 sm:top-10
        md:-left-4 md:top-20
        lg:-left-10 lg:top-28

        z-30
        animate-float-slow

        rounded-2xl lg:rounded-3xl
        border border-white/10
        bg-white/10
        p-3 sm:p-4 lg:p-5

        backdrop-blur-xl
        shadow-[0_25px_80px_rgba(0,0,0,.35)]
      `,children:[(0,D.jsxs)(`div`,{className:`mb-2 flex items-center gap-2 text-[11px] sm:text-xs font-medium text-orange-200`,children:[(0,D.jsx)(f,{size:14}),`Claims performance`]}),(0,D.jsx)(`div`,{className:`text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white`,children:`15M+`}),(0,D.jsx)(`p`,{className:`mt-1 text-xs sm:text-sm text-white/50`,children:`Claims paid successfully`})]})}function L(){return(0,D.jsx)(`div`,{className:`
        absolute
        right-0 top-28
        sm:right-6 sm:top-28
        md:-right-4 md:top-36
        lg:-right-10 lg:top-40

        z-30
        animate-float

        rounded-2xl lg:rounded-3xl
        border border-white/10
        bg-white/10

        px-3 py-3
        sm:px-4 sm:py-4
        lg:px-5 lg:py-4

        backdrop-blur-xl
        shadow-[0_25px_80px_rgba(0,0,0,.35)]
      `,children:(0,D.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,D.jsx)(`div`,{className:`flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-full bg-emerald-500/20`,children:(0,D.jsx)(d,{size:18,className:`text-emerald-400`})}),(0,D.jsxs)(`div`,{children:[(0,D.jsx)(`p`,{className:`text-xs sm:text-sm font-semibold text-white`,children:`Quote Approved`}),(0,D.jsx)(`p`,{className:`text-[10px] sm:text-xs text-white/50`,children:`2 seconds ago`})]})]})})}function R(){return(0,D.jsx)(`div`,{className:`
        absolute
        bottom-24 right-16
        sm:bottom-10 sm:right-6
        md:bottom-20 md:right-16
        lg:bottom-36 lg:right-28

        z-30
        animate-float-delayed

        rounded-2xl lg:rounded-3xl
        border border-white/10
        bg-white/10

        px-3 py-3
        sm:px-4 sm:py-4
        lg:px-5 lg:py-4

        backdrop-blur-xl
        shadow-[0_25px_80px_rgba(0,0,0,.35)]
      `,children:(0,D.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,D.jsx)(`div`,{className:`flex h-9 w-9 sm:h-10 sm:w-10 lg:h-11 lg:w-11 items-center justify-center rounded-2xl bg-blue-500/20`,children:(0,D.jsx)(S,{size:20,className:`text-blue-300`})}),(0,D.jsxs)(`div`,{children:[(0,D.jsx)(`p`,{className:`text-xs sm:text-sm font-semibold text-white`,children:`AI Risk Analysis`}),(0,D.jsxs)(`div`,{className:`mt-1 flex items-center gap-2`,children:[(0,D.jsx)(`div`,{className:`h-2 w-16 sm:w-20 lg:w-24 overflow-hidden rounded-full bg-white/10`,children:(0,D.jsx)(`div`,{className:`h-full w-[97%] rounded-full bg-gradient-to-r from-blue-400 to-cyan-300`})}),(0,D.jsx)(`span`,{className:`text-[10px] sm:text-xs text-white/70`,children:`97%`})]})]})]})})}function z({loaded:e}){return(0,D.jsxs)(`div`,{className:`
        relative
        flex
        items-center
        justify-center
        w-full
        min-h-[500px]
        md:min-h-[620px]
        lg:min-h-[720px]
        ${e?`animate-right delay-3`:``}
      `,children:[(0,D.jsx)(`div`,{className:`
          absolute
          h-[420px]
          w-[420px]
          md:h-[500px]
          md:w-[500px]
          lg:h-[600px]
          lg:w-[600px]
          rounded-full
          bg-orange-500/20
          blur-[120px]
          lg:blur-[150px]
        `}),(0,D.jsx)(`div`,{className:`
          absolute
          right-0
          top-12
          lg:top-20
          h-[320px]
          w-[320px]
          md:h-[420px]
          md:w-[420px]
          lg:h-[500px]
          lg:w-[500px]
          rounded-full
          bg-sky-500/15
          blur-[120px]
          lg:blur-[180px]
        `}),(0,D.jsxs)(`div`,{className:`relative z-20 flex justify-center`,children:[(0,D.jsx)(`img`,{src:F,alt:`Container Truck`,className:`
            w-full
            max-w-[420px]
            md:max-w-[520px]
            lg:max-w-[620px]
            xl:max-w-[680px]
            drop-shadow-[0_40px_100px_rgba(0,0,0,.45)]
            transition-transform
            duration-700
            hover:scale-[1.02]
          `}),(0,D.jsx)(`div`,{className:`
            absolute
            left-8
            right-8
            bottom-[-45px]
            lg:bottom-[-55px]
            h-20
            bg-gradient-to-b
            from-white/10
            to-transparent
            blur-3xl
            opacity-20
          `})]}),(0,D.jsx)(I,{}),(0,D.jsx)(L,{}),(0,D.jsx)(R,{}),(0,D.jsx)(`div`,{className:`
          absolute
          h-[520px]
          w-[520px]
          md:h-[620px]
          md:w-[620px]
          lg:h-[700px]
          lg:w-[700px]
          rounded-full
          border
          border-white/5
        `}),(0,D.jsx)(`div`,{className:`
          absolute
          h-[380px]
          w-[380px]
          md:h-[450px]
          md:w-[450px]
          lg:h-[520px]
          lg:w-[520px]
          rounded-full
          border
          border-white/5
        `})]})}var ee={soft:`M0,40 C360,80 1080,0 1440,40 L1440,80 L0,80 Z`,curve:`M0,60 C240,20 480,20 720,60 C960,100 1200,100 1440,60 L1440,80 L0,80 Z`,sharp:`M0,0 L1440,80 L1440,80 L0,80 Z`,layered:`M0,50 C300,100 1140,0 1440,50 L1440,80 L0,80 Z`,minimal:`M0,40 Q720,0 1440,40 L1440,80 L0,80 Z`},B={blue:{start:`#2563eb`,end:`#60a5fa`},white:{start:`#f8fafc`,end:`#f8fafc`}};function V({variant:e=`soft`,flip:t=!1,className:n,animated:r=!1,customPath:i,color:o=`blue`}){let s=i||ee[e],c=B[o];return(0,D.jsx)(`div`,{"aria-hidden":`true`,className:a(`absolute bottom-0 left-0 w-full overflow-hidden leading-none pointer-events-none`,n),style:{transform:t?`rotate(180deg)`:void 0},children:(0,D.jsxs)(`svg`,{viewBox:`0 0 1440 80`,preserveAspectRatio:`none`,className:`w-full h-full`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`wave-gradient-${o}`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`0%`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:c.start,stopOpacity:`1`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:c.end,stopOpacity:`1`})]})}),(0,D.jsx)(`path`,{d:s,fill:`url(#wave-gradient-${o})`,className:a(r&&`animate-[waveFloat_8s_ease-in-out_infinite_alternate]`)})]})})}function H(){return(0,D.jsx)(`div`,{className:`
      absolute
      inset-0

      bg-[radial-gradient(circle_at_15%_20%,rgba(59,130,246,.35),transparent_35%),radial-gradient(circle_at_85%_25%,rgba(14,165,233,.22),transparent_35%),radial-gradient(circle_at_50%_90%,rgba(30,64,175,.35),transparent_45%)]
      `})}function U(){return(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(`div`,{className:`
absolute
-top-48
-left-36

h-[500px]
w-[500px]

rounded-full

bg-blue-400/20

blur-[180px]
`}),(0,D.jsx)(`div`,{className:`
absolute

right-[-180px]

top-32

h-[650px]

w-[650px]

rounded-full

bg-sky-500/15

blur-[220px]
`}),(0,D.jsx)(`div`,{className:`
absolute

bottom-[-220px]

left-1/2

h-[700px]

w-[700px]

-translate-x-1/2

rounded-full

bg-cyan-400/10

blur-[220px]
`})]})}function W(){return(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(`div`,{className:`
        pointer-events-none

        absolute

        right-[-220px]

        top-1/2

        hidden

        h-[900px]

        w-[900px]

        -translate-y-1/2

        rounded-full

        border

        border-blue-200/[0.08]

        lg:block

        animate-pulse-slow
        `}),(0,D.jsx)(`div`,{className:`
        pointer-events-none

        absolute

        right-[-80px]

        top-1/2

        hidden

        h-[650px]

        w-[650px]

        -translate-y-1/2

        rounded-full

        border

        border-white/[0.08]

        lg:block
        `}),(0,D.jsx)(`div`,{className:`
        pointer-events-none

        absolute

        right-[80px]

        top-1/2

        hidden

        h-[420px]

        w-[420px]

        -translate-y-1/2

        rounded-full

        border

        border-orange-400/[0.12]

        lg:block
        `})]})}function G(){return(0,D.jsx)(`div`,{className:`
absolute

inset-0

opacity-[0.04]

[background-image:linear-gradient(rgba(255,255,255,.7)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.7)_1px,transparent_1px)]

[background-size:72px_72px]
`})}function K(){return(0,D.jsx)(`div`,{className:`
absolute

inset-0

opacity-[0.025]

mix-blend-soft-light

bg-noise
`})}var q=[{size:`h-2 w-2`,position:`left-[15%] top-[25%]`,delay:`0s`},{size:`h-1.5 w-1.5`,position:`left-[35%] top-[70%]`,delay:`2s`},{size:`h-2.5 w-2.5`,position:`right-[25%] top-[30%]`,delay:`4s`},{size:`h-1 w-1`,position:`right-[12%] bottom-[30%]`,delay:`6s`},{size:`h-1.5 w-1.5`,position:`left-[60%] top-[18%]`,delay:`8s`}];function J(){return(0,D.jsx)(D.Fragment,{children:q.map((e,t)=>(0,D.jsx)(`span`,{style:{animationDelay:e.delay},className:`
          pointer-events-none

          absolute

          ${e.position}

          ${e.size}

          rounded-full

          bg-blue-200/50

          blur-[1px]

          animate-particle-float
          `},t))})}function Y(){return(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(H,{}),(0,D.jsx)(U,{}),(0,D.jsx)(W,{}),(0,D.jsx)(G,{}),(0,D.jsx)(K,{}),(0,D.jsx)(J,{})]})}function X(){return(0,D.jsxs)(`section`,{className:`
        relative
        isolate
        overflow-hidden

        bg-gradient-to-r
        from-blue-950
        via-blue-900
        to-slate-900

        text-white
      `,children:[(0,D.jsx)(Y,{}),(0,D.jsx)(n,{className:`
          relative
          z-20

          flex
          items-center

          min-h-screen

          pt-28
          pb-16

          sm:pt-32
          sm:pb-20

          lg:pt-36
          lg:pb-24
        `,children:(0,D.jsxs)(`div`,{className:`
            w-full

            flex
            flex-col

            items-center

            gap-2

            md:gap-20

            lg:grid
            lg:grid-cols-[1.1fr_.9fr]
            lg:items-center
            lg:gap-24
          `,children:[(0,D.jsx)(`div`,{className:`w-full`,children:(0,D.jsx)(P,{loaded:!0})}),(0,D.jsx)(`div`,{className:`
              flex
              w-full
              justify-center

              lg:justify-end
            `,children:(0,D.jsx)(z,{loaded:!0})})]})}),(0,D.jsx)(V,{color:`white`})]})}var Z=[{id:`cargo`,icon:`truck`,theme:`primary`,name:`Cargo Insurance`,shortDesc:`Comprehensive coverage for goods in transit across borders`,to:`/products?type=cargo`},{id:`yellow-card`,icon:`location`,theme:`success`,name:`Yellow Card`,shortDesc:`COMESA cross-border motor insurance for regional travel`,to:`/products?type=yellow-card`},{id:`fleet`,icon:`shield`,theme:`purple`,name:`Fleet Coverage`,shortDesc:`Protect your entire commercial vehicle fleet`,to:`/products?type=vehicle`},{id:`liability`,icon:`document`,theme:`warning`,name:`Liability`,shortDesc:`Third-party liability protection for peace of mind`,to:`/products?type=liability`}],Q={placeholder:l,check:h,arrowRight:u,shield:m,clock:y,globe:c,users:g},$={primary:`bg-gradient-to-br from-[#2B7FFF] to-[#155DFC] text-white`,success:`bg-gradient-to-br from-[#00BC7D] to-[#096] text-white`,warning:`bg-gradient-to-br from-[#FF6900] to-[#F54900] text-white`,purple:`bg-gradient-to-br from-[#615FFF] to-[#4F39F6] text-white`};function te(){return(0,D.jsx)(`section`,{className:`py-20 bg-white`,children:(0,D.jsxs)(n,{children:[(0,D.jsxs)(`div`,{className:`mb-12 text-center `,children:[(0,D.jsx)(`div`,{className:`d-inline-block w-full`,children:(0,D.jsx)(v,{variant:`title`,className:`font-bold`,children:`Insurance Solutions Built for Africa`})}),(0,D.jsx)(v,{variant:`sm`,className:`mt-2 text-muted`,children:`Tailored coverage for every stage of your transport and logistics journey`})]}),(0,D.jsx)(_,{direction:`row`,gap:`lg`,children:(0,D.jsx)(`div`,{className:`grid md:grid-cols-2 xl:grid-cols-4 gap-8`,children:Z.map(e=>{let n=Q[(e.icon||``).toLowerCase()]||Q.placeholder;return(0,D.jsx)(t,{to:e.to,children:(0,D.jsxs)(i,{variant:`glass`,className:`group flex flex-col p-6 rounded-2xl border border-black/10 hover:bg-[#F8FAFC] hover:shadow-lg transition-transform duration-300 hover:scale-105`,children:[(0,D.jsx)(`div`,{className:`mb-4 flex h-14 w-14 items-center justify-center rounded-md transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110 shadow-md ${$[e.theme]||$.primary}`,children:(0,D.jsx)(n,{className:`h-7 w-7`})}),(0,D.jsx)(v,{variant:`body`,className:`font-semibold text-lg group-hover:text-[#E65731]`,children:e.name}),(0,D.jsx)(v,{variant:`sm`,className:`mt-2 text-muted flex-grow`,children:e.shortDesc}),(0,D.jsx)(v,{variant:`sm`,className:`mt-4 font-medium text-[#E65731]`,children:(0,D.jsxs)(`span`,{className:`flex items-center gap-2 text-sm text-[--color-orange]`,children:[`Learn more`,(0,D.jsx)(b,{className:`h-4 w-4 transition-transform group-hover:translate-x-2`})]})})]})},e.id)})})})]})})}function ne(){return(0,D.jsx)(`section`,{className:`py-16`,children:(0,D.jsx)(n,{children:(0,D.jsx)(`div`,{className:`grid md:grid-cols-4 gap-8`,children:E.map(e=>(0,D.jsxs)(i,{variant:`solid`,className:`self-start flex flex-col items-center text-center p-6 bg-white shadow-sm group`,children:[(0,D.jsx)(`div`,{className:`mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-[#233C7B] to-[#0EA572] transition-transform duration-200 group-hover:scale-110`,children:(0,D.jsx)(Q[e.icon]||Q.placeholder,{className:`h-6 w-6 text-white`})}),(0,D.jsx)(v,{variant:`body`,className:`font-semibold`,children:e.label}),(0,D.jsx)(v,{variant:`sm`,className:`mt-1 text-muted-foreground`,children:e.subtext})]},e.id))})})})}var re=[{id:`1`,label:`Instant digital quotes and policy issuance`},{id:`2`,label:`24/7 claims support across all borders`},{id:`3`,label:`Real-time tracking of claim status`},{id:`4`,label:`Pan-African coverage network`},{id:`5`,label:`Flexible payment options`},{id:`6`,label:`Expert risk assessment`}],ie=`/assets/Trucks-B6SV8GIb.svg`;function ae(){return(0,D.jsx)(`section`,{className:`bg-slate-50 py-20`,children:(0,D.jsxs)(n,{children:[(0,D.jsx)(`div`,{className:`mb-12 text-center`,children:(0,D.jsxs)(_,{direction:`col`,gap:`md`,children:[(0,D.jsx)(v,{variant:`body`,className:`inline-block max-w-fit px-6 py-2 bg-green-100 text-green-700 font-bold rounded-full`,children:`Why Choose Us`}),(0,D.jsx)(v,{variant:`title`,className:`mt-4 ml-0 text-start max-w-sm text-3xl md:text-4xl font-bold`,children:`Why Transporters Choose Askari`})]})}),(0,D.jsxs)(`div`,{className:`grid md:grid-cols-2 items-center gap-10`,children:[(0,D.jsxs)(_,{direction:`col`,gap:`md`,children:[(0,D.jsx)(x,{items:re.map(e=>({id:e.id,label:e.label,type:`check`}))}),(0,D.jsx)(o,{className:`mt-6 w-max px-6 py-3 bg-[#071a54] rounded-full transition-transform duration-200 hover:scale-105`,iconRight:(0,D.jsx)(u,{size:20}),children:(0,D.jsx)(t,{to:`about`,children:`Learn More About Us`})})]}),(0,D.jsxs)(`div`,{className:`relative flex justify-center`,children:[(0,D.jsx)(`div`,{className:`
                absolute
                -top-0
                -left-0
                -right-0
                bottom-12
                rotate-[2deg]
                rounded-3xl
                bg-gradient-to-br
                from-[#233C7B]/10
                to-[#0EA572]/10
              `}),(0,D.jsx)(`img`,{src:ie,alt:`Why Choose Us`,className:`
              w-full
              max-w-[608px]
              h-auto
              `})]})]})]})})}function oe(){return(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(X,{}),(0,D.jsx)(ne,{}),(0,D.jsx)(te,{}),(0,D.jsx)(ae,{})]})}export{oe as default};