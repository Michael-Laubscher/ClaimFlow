import{a as e,i as t,n,r}from"./Button-COsPX9A4.js";import{n as i,t as a}from"./SectionHeader-DmqdBUgL.js";import{S as o,X as s,Y as c,b as l,h as u,x as d}from"./index-C2dflxg-.js";import{n as f,t as p}from"./about.config.data-DKWNL8L1.js";var m=n(`star`,[[`path`,{d:`M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z`,key:`r04s7s`}]]),h=`/assets/BrandImage-CwRlSA1_.svg`,g=e();function _({title:e,subtitle:n,description:r,layout:i=`grid`,className:a=``,children:u,left:d,right:f,items:p=[],renderItem:m,columns:h=`grid gap-6`}){return(0,g.jsx)(l,{className:a,children:(0,g.jsxs)(t,{children:[(e||n||r)&&(0,g.jsx)(`div`,{className:`
mb-16
mx-auto
max-w-3xl
text-center
`,children:(0,g.jsxs)(s,{gap:`sm`,children:[n&&(0,g.jsx)(c,{className:`
text-xs
uppercase
tracking-[0.3em]
text-slate-400
`,children:n}),e&&(0,g.jsx)(o,{className:`
text-4xl
font-black
tracking-tight
`,children:e}),r&&(0,g.jsx)(c,{color:`muted`,className:`mt-4`,children:r})]})}),i===`split`&&(0,g.jsxs)(`div`,{className:`
grid
items-center
gap-16
lg:grid-cols-2
`,children:[d,f]}),i===`cards`&&(0,g.jsx)(`div`,{className:`
grid
gap-8
md:grid-cols-2
lg:grid-cols-3
`,children:p.map((e,t)=>(0,g.jsx)(`div`,{children:m?.(e)},t))}),i===`stats`&&(0,g.jsx)(`div`,{className:`grid gap-12 text-center sm:grid-cols-3`,children:p.map(e=>(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`div`,{className:`text-5xl font-black tracking-tight text-white`,children:e.value}),(0,g.jsx)(`div`,{className:`mt-3 text-xs uppercase tracking-[0.3em] text-white/60`,children:e.label})]},e.label))}),i===`grid`&&(0,g.jsx)(`div`,{className:h,children:u})]})})}var v=[{value:`98%`,label:`Client Satisfaction`},{value:`100+`,label:`Projects Delivered`},{value:`10+`,label:`Years of Experience`}],y=[{name:`John Smith`,role:`Operations Director`,company:`CargoLink Africa`,quote:`Askari transformed how we manage insurance across multiple logistics operations. The process is seamless and the support team is exceptional.`},{name:`Sarah Williams`,role:`Managing Director`,company:`TransGlobal Freight`,quote:`Working with Askari has given our business confidence to expand across borders knowing our operations are protected.`},{name:`David Nkosi`,role:`Regional Manager`,company:`FleetAxis`,quote:`Professional, responsive and knowledgeable. Their solutions fit perfectly into our logistics business.`}];function b(){return(0,g.jsx)(l,{className:`bg-slate-50 pb-28`,children:(0,g.jsx)(t,{children:(0,g.jsxs)(s,{gap:`lg`,children:[(0,g.jsx)(a,{centered:!0,badge:`Customer Stories`,title:`Trusted by Businesses Across Africa`,description:`Our partnerships are built on trust, reliability and long-term success.`}),(0,g.jsx)(`div`,{className:`grid gap-6 md:grid-cols-3`,children:v.map(e=>(0,g.jsxs)(r,{className:`rounded-3xl border-slate-200 bg-white p-8 text-center shadow-sm`,children:[(0,g.jsx)(`p`,{className:`text-4xl font-black text-[--color-navy]`,children:e.value}),(0,g.jsx)(c,{className:`
                    mt-2
                    uppercase
                    tracking-[0.15em]
                    text-slate-500
                    text-xs
                  `,children:e.label})]},e.label))}),(0,g.jsx)(`div`,{className:`grid gap-8 lg:grid-cols-3`,children:y.map(e=>(0,g.jsxs)(r,{className:`
                  group
                  relative
                  overflow-hidden
                  rounded-3xl
                  border-slate-200
                  bg-white
                  p-8
                  transition-all
                  duration-300
                  hover:-translate-y-2
                  hover:shadow-xl
                `,children:[(0,g.jsx)(i,{className:`
                    absolute
                    right-6
                    top-6
                    h-20
                    w-20
                    text-orange-500/10
                  `}),(0,g.jsxs)(s,{gap:`lg`,children:[(0,g.jsx)(`div`,{className:`flex gap-1 text-orange-500`,children:Array.from({length:5}).map((e,t)=>(0,g.jsx)(m,{className:`h-4 w-4 fill-current`},t))}),(0,g.jsxs)(c,{className:`leading-relaxed text-slate-600`,children:[`“`,e.quote,`”`]}),(0,g.jsxs)(`div`,{className:`border-t border-slate-100 pt-5`,children:[(0,g.jsx)(`p`,{className:`font-semibold text-slate-900`,children:e.name}),(0,g.jsx)(c,{className:`text-sm`,children:e.role}),(0,g.jsx)(c,{className:`text-sm text-[--color-orange]`,children:e.company})]})]})]},e.name))})]})})})}function x(){return(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(d,{...u.about}),(0,g.jsx)(_,{className:`
bg-white
py-28
`,layout:`split`,left:(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`span`,{className:`
inline-flex
rounded-full
bg-orange-100
px-4
py-2
text-xs
font-semibold
uppercase
tracking-wider
text-orange-600
`,children:`Our Story`}),(0,g.jsx)(o,{className:`
mt-6
text-5xl
font-black
tracking-tight
`,children:`Building trust across African trade`}),(0,g.jsx)(`div`,{className:`mt-8 space-y-5`,children:f.paragraphs.map(e=>(0,g.jsx)(c,{color:`muted`,className:`
leading-relaxed
`,children:e},e))})]}),right:(0,g.jsxs)(`div`,{className:`
relative
`,children:[(0,g.jsx)(`div`,{className:`
absolute
inset-0
rounded-[3rem]
bg-blue-500/10
blur-3xl
`}),(0,g.jsx)(`img`,{src:h,alt:`Askari brand`,className:`
relative
rounded-[3rem]
shadow-2xl
`})]})}),(0,g.jsx)(_,{subtitle:`Our Values`,title:`What Drives Us`,description:`
The principles that guide every partnership,
product and decision we make.
`,className:`
bg-slate-50
py-28
`,layout:`cards`,items:p,renderItem:e=>{let t=e.icon;return(0,g.jsxs)(r,{className:`
group
rounded-[2rem]
border-slate-200
bg-white
p-8
transition-all
duration-300
hover:-translate-y-2
hover:shadow-2xl
`,children:[(0,g.jsx)(`div`,{className:`
flex
h-16
w-16
items-center
justify-center
rounded-2xl
bg-gradient-to-br
${{blue:`from-blue-500 to-blue-700`,green:`from-emerald-500 to-emerald-700`,purple:`from-purple-500 to-purple-700`,orange:`from-orange-500 to-orange-700`,teal:`from-teal-500 to-teal-700`}[e.iconColor]}
text-white
shadow-lg
`,children:(0,g.jsx)(t,{className:`
h-8
w-8
`})}),(0,g.jsx)(`h3`,{className:`
mt-6
text-xl
font-bold
text-slate-900
`,children:e.title}),(0,g.jsx)(`p`,{className:`
mt-3
leading-relaxed
text-slate-500
`,children:e.desc})]})}}),(0,g.jsx)(b,{})]})}export{x as default};