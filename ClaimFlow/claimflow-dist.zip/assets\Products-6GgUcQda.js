import{a as e,i as t}from"./Button-COsPX9A4.js";import{b as n,x as r}from"./index-C2dflxg-.js";import{t as i}from"./FeatureCard-z1H7I6DP.js";import{t as a}from"./products.config-BqVLU_DV.js";var o=e();function s(){return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(r,{title:`Insurance Products`,subtitle:`
          Comprehensive insurance solutions for
          transport and logistics businesses.
        `}),(0,o.jsx)(n,{className:`bg-[--color-slate-50] py-16`,children:(0,o.jsx)(t,{children:(0,o.jsx)(`div`,{className:`
              grid
              grid-cols-1
              gap-5
              md:grid-cols-2
            `,children:a.map(e=>(0,o.jsx)(i,{title:e.name,description:e.tagline,icon:e.icon,badge:`Insurance`,to:`/products/${e.id}`},e.id))})})})]})}export{s as default};