import{a as e,r as t}from"./Button-COsPX9A4.js";import{S as n,X as r,Y as i}from"./index-C2dflxg-.js";var a=e();function o({children:e}){return(0,a.jsx)(`span`,{className:`
        rounded-full
        bg-[--color-orange]
        px-2
        py-0.5
        text-[10px]
        font-semibold
        text-white
      `,children:e})}function s({title:e,badge:s,icon:c,label:l,description:u,items:d,variant:f=`glass`,className:p}){return(0,a.jsx)(t,{variant:f,className:`
relative
overflow-hidden
rounded-3xl
${p}
`,children:(0,a.jsxs)(r,{gap:`lg`,children:[(e||s)&&(0,a.jsxs)(`div`,{className:`flex items-center justify-between`,children:[e&&(0,a.jsx)(n,{as:`h3`,size:`lg`,children:e}),s&&(0,a.jsx)(o,{children:s})]}),(l||c)&&(0,a.jsxs)(`div`,{className:`flex items-start gap-4`,children:[c&&(0,a.jsx)(`div`,{className:`
flex
h-10
w-10
items-center
justify-center
rounded-2xl
bg-orange-500/10
`,children:c}),(0,a.jsxs)(`div`,{children:[(0,a.jsx)(i,{variant:`body`,className:`font-medium`,children:l}),u&&(0,a.jsx)(i,{variant:`sm`,color:`muted`,className:`mt-1`,children:u})]})]}),d&&(0,a.jsx)(`div`,{className:`space-y-5`,children:d.map((e,t)=>(0,a.jsxs)(`div`,{className:`flex items-start gap-4`,children:[(0,a.jsx)(`div`,{className:`
flex
h-10
w-10
items-center
justify-center
rounded-2xl
bg-orange-500/10
`,children:e.icon}),(0,a.jsxs)(`div`,{children:[(0,a.jsx)(i,{variant:`sm`,className:`font-medium`,children:e.label}),e.description&&(0,a.jsx)(i,{variant:`sm`,color:`muted`,children:e.description})]})]},t))})]})})}export{s as t};