import{a as e,i as t,n}from"./Button-COsPX9A4.js";import{t as r}from"./clock-3-D9DNny55.js";import{t as i}from"./phone-Csz4IsfM.js";import{b as a,x as o}from"./index-C2dflxg-.js";import{t as s}from"./InfoCard-BJYien5R.js";var c=n(`map-pin`,[[`path`,{d:`M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0`,key:`1r0f0z`}],[`circle`,{cx:`12`,cy:`10`,r:`3`,key:`ilqhr7`}]]),l=[{id:1,name:`Nairobi`,flagship:!0,address:`2nd Floor, Business District, P.O. Box 12345-00100`,city:`Nairobi, Kenya`,phone:`+254 700 000 000`,hours:`Mon-Fri: 8am-6pm, Sat: 9am-2pm`},{id:2,name:`Mombasa`,address:`Mombasa Port Area, P.O. Box 54321-80100`,city:`Mombasa, Kenya`,phone:`+254 700 000 001`,hours:`Mon-Fri: 8am-6pm, Sat: 9am-2pm`},{id:3,name:`Kampala`,address:`Kampala Industrial Area, P.O. Box 11111`,city:`Kampala, Uganda`,phone:`+256 700 000 000`,hours:`Mon-Fri: 8am-6pm, Sat: 9am-2pm`},{id:4,name:`Dar es Salaam`,address:`Dar es Salaam Port District`,city:`Dar es Salaam, Tanzania`,phone:`+255 700 000 000`,hours:`Mon-Fri: 8am-6pm, Sat: 9am-2pm`},{id:5,name:`Kigali`,address:`Kigali Business Center`,city:`Kigali, Rwanda`,phone:`+250 700 000 000`,hours:`Mon-Fri: 8am-6pm, Sat: 9am-2pm`},{id:6,name:`Addis Ababa`,address:`Addis Ababa Trade Hub`,city:`Addis Ababa, Ethiopia`,phone:`+251 700 000 000`,hours:`Mon-Fri: 8am-6pm, Sat: 9am-2pm`}],u=e();function d(){return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(o,{badge:`Regional Presence`,title:`Our Branch Network`,subtitle:`
Find an Askari Insure office near you.
Our teams are positioned across key African
trade and logistics corridors.
`}),(0,u.jsx)(a,{className:`bg-slate-50 py-24`,children:(0,u.jsxs)(t,{size:`xl`,children:[(0,u.jsxs)(`div`,{className:`
mb-14

max-w-3xl

`,children:[(0,u.jsx)(`h2`,{className:`
text-3xl

font-bold

tracking-tight

text-slate-900

`,children:`Local expertise. Regional protection.`}),(0,u.jsx)(`p`,{className:`
mt-4

text-slate-600

leading-relaxed

`,children:`Visit one of our branches for personalised support, claims assistance, and insurance solutions designed for African businesses.`})]}),(0,u.jsx)(`div`,{className:`
grid

gap-8

md:grid-cols-2

xl:grid-cols-3

`,children:l.map(e=>(0,u.jsx)(s,{title:e.name,badge:e.flagship?`Flagship`:void 0,className:`
h-full

p-7

transition-all

duration-300

hover:-translate-y-2

`,items:[{icon:(0,u.jsx)(c,{size:20,className:`text-orange-500`}),label:e.address,description:e.city},{icon:(0,u.jsx)(i,{size:20,className:`text-orange-500`}),label:e.phone},{icon:(0,u.jsx)(r,{size:20,className:`text-orange-500`}),label:e.hours}]},e.id))})]})})]})}export{d as default};